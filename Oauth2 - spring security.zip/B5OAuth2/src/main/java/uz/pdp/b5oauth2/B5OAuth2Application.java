package uz.pdp.b5oauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B5OAuth2Application {

    public static void main(String[] args) {
        SpringApplication.run(B5OAuth2Application.class, args);
    }

}
